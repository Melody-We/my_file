import pandas as pd

flag=0
def main():
    print('欢迎来到动物识别系统！')
    print('请输入该动物的特征：')
    describe = input()
    book = pd.read_excel('animal.xlsx',sheet_name='Sheet1',header=0)
    #print(len(book))
    data1=book.values
    '''data2=book.describe
    
    data3=book.conclusion'''

    #print(type(book))
    inputlist = list(describe.split('，'))

    dic = dict()
    for i in range(len(book)):
        title = str(data1[i][1])
        value = str(data1[i][2])
        dic[title]=value
    #print(len(dic))
    flag1=0
    i=0
    while(flag1==0):
        for key in dic.keys():
            keylist = list(key.split('，'))
            if (len(inputlist) == 1):
                if keylist == inputlist:
                    inputlist[0] = dic[key]
                    flag1=flag = 1
                    break
                else:
                    flag = 0
            '''if (describe == key):
                flag=1
                break'''
            # d=[True for char in keylist if char in inputlist]

            if set(keylist).issubset(inputlist):  # 判断key是否是inputlist的子集
                if (dic[key] == '有蹄动物，偶蹄动物'):
                    dic[key] = '有蹄动物'
                inputlist.insert(0, dic[key])
                # inputlist.remove([m for m in keylist])
                for m in keylist:
                    inputlist.remove(m)
                del dic[key]
                flag = 1
                break
                if (len(inputlist) == 1):
                    flag1=flag=1
                    break
                else:
                    flag = 0
        i=i+1
        if(i>=len(inputlist)):#最多循环len(inputlist）次就可以判断出给动物类型，繁殖死循环
            break

    if(flag==1):
        alist=list(inputlist[0])
        blist=['动','物']
        if set(blist).issubset(alist):
            print('很抱歉，根据您提示的信息我们只能推测它为'+inputlist[0])
        else:
            print('该动物为：'+inputlist[0])
    else:
        print('不能识别该动物')

main()
